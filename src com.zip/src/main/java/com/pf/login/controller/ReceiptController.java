package com.pf.login.controller;

import com.pf.login.entity.ReceiptOne;
import com.pf.login.dto.ReceiptRequestDto;
import com.pf.login.dto.ReceiptBillDto;
import com.pf.login.service.ReceiptService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/receipts")
@CrossOrigin(origins = "http://localhost:3000")
public class ReceiptController {

    private final ReceiptService receiptService;

    public ReceiptController(ReceiptService receiptService) {
        this.receiptService = receiptService;
    }

    // ✅ Save CDA Receipt
    @PostMapping("/cda")
    public String saveCdaReceipt(@RequestBody ReceiptRequestDto dto) {
        receiptService.saveCdaReceipt(dto);
        return "Receipt from CDA saved successfully";
    }

    // ✅ Latest Receipt (NOW RETURNS contno ALSO)
    @GetMapping("/latest")
    public Map<String, Object> getLatestReceipt() {

        ReceiptOne receipt = receiptService.getLatestReceipt();

        return Map.of(
                "contno", receipt.getContno(),   // ✅ IMPORTANT
                "recNo", receipt.getRecNo(),
                "dvnoRefno", receipt.getDvnoRefno(),
                "chequeReceiptNo", receipt.getChequeReceiptNo(),
                "chequeReceiptDate", receipt.getChequeReceiptDate(),
                "amount", receipt.getAmount(),
                "bankCreditDate", receipt.getBankCreditDate()
        );
    }

    // ✅ Bills page → only latest record using MAX(contno)
    @GetMapping("/bill/latest")
    public ReceiptBillDto getLatestBillData() {
        return receiptService.getLatestBillReceipt();
    }
}
