export default function CdaBillPage() {
  return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <h2>CDA BILLPAGE</h2>
    </div>
  );
}
