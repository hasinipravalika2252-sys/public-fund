import { Routes, Route } from "react-router-dom";
import LoginPage from "./LoginPage";
import Receipts from "./Receipts";
import CDAReceipt from "./CDAReceipt";
import Bills from "./Bills";
import CdaBillPage from "./CdaBillPage";

function App() {
  return (
    <Routes>
      <Route path="/" element={<LoginPage />} />
      <Route path="/receipts" element={<Receipts />} />
      <Route path="/cda-receipt" element={<CDAReceipt />} />
      <Route path="/bills" element={<Bills />} />
      <Route path="/cdabillpage" element={<CdaBillPage />} />
    </Routes>
  );
}

export default App;
