package com.pf.login.controller;

import com.pf.login.dto.ChequeDdReceiptDto;
import com.pf.login.service.ChequeDdReceiptService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cheque-dd")
@CrossOrigin
public class ChequeDdReceiptController {

    private final ChequeDdReceiptService chequeDdReceiptService;

    public ChequeDdReceiptController(
            ChequeDdReceiptService chequeDdReceiptService) {
        this.chequeDdReceiptService = chequeDdReceiptService;
    }

    @PostMapping("/save")
    public ResponseEntity<?> save(
            @RequestBody ChequeDdReceiptDto dto) {

        chequeDdReceiptService.saveChequeDdReceipt(dto);

        return ResponseEntity.ok("Saved Successfully");
    }
}