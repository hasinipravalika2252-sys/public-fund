package com.pf.login.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
import java.time.LocalDate;

public class ChequeDdReceiptDto {

    private String chequeDdNo;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate chequeDdDate;

    private String referenceNo;

    private String purpose;

    private String fromWhom;

    private BigDecimal amount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate bankCreditDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate loginDate;

    public String getChequeDdNo() {
        return chequeDdNo;
    }

    public void setChequeDdNo(String chequeDdNo) {
        this.chequeDdNo = chequeDdNo;
    }

    public LocalDate getChequeDdDate() {
        return chequeDdDate;
    }

    public void setChequeDdDate(LocalDate chequeDdDate) {
        this.chequeDdDate = chequeDdDate;
    }

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getFromWhom() {
        return fromWhom;
    }

    public void setFromWhom(String fromWhom) {
        this.fromWhom = fromWhom;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public LocalDate getBankCreditDate() {
        return bankCreditDate;
    }

    public void setBankCreditDate(LocalDate bankCreditDate) {
        this.bankCreditDate = bankCreditDate;
    }

    public LocalDate getLoginDate() {
        return loginDate;
    }

    public void setLoginDate(LocalDate loginDate) {
        this.loginDate = loginDate;
    }
}