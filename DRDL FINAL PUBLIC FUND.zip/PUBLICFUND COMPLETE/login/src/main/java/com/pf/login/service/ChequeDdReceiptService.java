package com.pf.login.service;

import com.pf.login.dto.ChequeDdReceiptDto;
import com.pf.login.entity.RBillOne;
import com.pf.login.entity.ReceiptOne;
import com.pf.login.entity.Trcd;
import com.pf.login.repository.RBillOneRepository;
import com.pf.login.repository.ReceiptRepository;
import com.pf.login.repository.TrcdRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
public class ChequeDdReceiptService {

    private final ReceiptRepository receiptRepository;
    private final RBillOneRepository rBillOneRepository;
    private final TrcdRepository trcdRepository;

    public ChequeDdReceiptService(
            ReceiptRepository receiptRepository,
            RBillOneRepository rBillOneRepository,
            TrcdRepository trcdRepository) {

        this.receiptRepository = receiptRepository;
        this.rBillOneRepository = rBillOneRepository;
        this.trcdRepository = trcdRepository;
    }

    @Transactional
    public void saveChequeDdReceipt(
            ChequeDdReceiptDto dto) {

        String year = String.valueOf(dto.getLoginDate().getYear());

Long maxContno = receiptRepository.findMaxContnoForYear(year);

long nextContSeq =
        (maxContno == null)
                ? 1
                : (maxContno % 100000) + 1;

Long contno =
        Long.parseLong(year + String.format("%05d", nextContSeq));


// REC_NO Generation

String yearMonth =
        year +
        String.format("%02d",
                dto.getLoginDate().getMonthValue());

String maxRecNo =
        receiptRepository.findMaxRecNoForMonth(yearMonth);

int nextRecSeq =
        (maxRecNo == null)
                ? 1
                : Integer.parseInt(
                        maxRecNo.substring(6)
                  ) + 1;

String recNo =
        yearMonth +
        String.format("%04d", nextRecSeq);


// RVNO Generation

Long rvStart =
        Long.parseLong(yearMonth + "0000");

Long rvEnd =
        Long.parseLong(yearMonth + "9999");

Long maxRvno =
        rBillOneRepository.findMaxRvnoInRange(
                rvStart,
                rvEnd
        );

Long rvno;

if (maxRvno == null) {

    rvno = Long.parseLong(yearMonth + "0001");

} else {

    rvno = maxRvno + 1;
}


// TRCD R5

Trcd trcd =
        trcdRepository.findById("R5")
                .orElseThrow(() ->
                        new RuntimeException(
                                "TRCD R5 not found"
                        ));
                        ReceiptOne receipt = new ReceiptOne();

receipt.setContno(contno);

receipt.setDvnoRefno(dto.getReferenceNo());

receipt.setRvno(rvno);

receipt.setChequeReceiptNo(
        Long.parseLong(dto.getChequeDdNo())
);

receipt.setAmount(dto.getAmount());

receipt.setBalance(dto.getAmount());

receipt.setTrcd("R5");

receipt.setTrcdDesc(trcd.getTrcdDesc());

receipt.setTrDate(dto.getLoginDate());

receipt.setChequeReceiptDate(dto.getChequeDdDate());

receipt.setRPurpose(dto.getPurpose());

receipt.setChequeCash("CH");

receipt.setFromAddress(dto.getFromWhom());

receipt.setRType("MIS");

receipt.setAlertFlag("N");

receipt.setRecNo(recNo);

receipt.setBankCreditDate(
        dto.getBankCreditDate()
);
RBillOne bill = new RBillOne();

bill.setContno(contno);

bill.setRvno(rvno);

bill.setBillNo(null);

bill.setBillDate(null);

bill.setType("MIS");

bill.setPurpose(dto.getPurpose());

bill.setBillAmount(dto.getAmount());

bill.setBalance(dto.getAmount());

bill.setAlertFlag("N");
receiptRepository.save(receipt);

rBillOneRepository.save(bill);

System.out.println(contno);
System.out.println(recNo);
System.out.println(rvno);
System.out.println(trcd.getTrcdDesc());

    }
}