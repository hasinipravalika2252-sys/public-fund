import React, { useState } from "react";
import "./ChequeDdReceipt.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const ChequeDdReceipt = () => {

  const navigate = useNavigate();

  const [receipt, setReceipt] = useState({
    chequeDdNo: "",
    chequeDdDate: "",
    referenceNo: "",
    purpose: "",
    fromWhom: "",
    amount: "",
    bankCreditDate: "",
  });

  const handleChange = (e) => {

    setReceipt({
      ...receipt,
      [e.target.name]: e.target.value,
    });
  };

  // ✅ SAVE FUNCTION
  const handleSubmit = async (e) => {

    e.preventDefault();
    if (!receipt.chequeDdNo) {
  alert("Cheque / DD No is required");
  return;
}

if (!receipt.chequeDdDate) {
  alert("Cheque / DD Date is required");
  return;
}

if (!receipt.referenceNo) {
  alert("Reference No is required");
  return;
}

if (!receipt.purpose) {
  alert("Purpose is required");
  return;
}

if (!receipt.fromWhom) {
  alert("From Whom is required");
  return;
}

if (!receipt.amount) {
  alert("Amount is required");
  return;
}

if (!receipt.bankCreditDate) {
  alert("Bank Credit Date is required");
  return;
}

    try {

     const payload = {

  chequeDdNo: receipt.chequeDdNo,

  chequeDdDate: receipt.chequeDdDate,

  referenceNo: receipt.referenceNo,

  purpose: receipt.purpose,

  fromWhom: receipt.fromWhom,

  amount: receipt.amount,

  bankCreditDate: receipt.bankCreditDate,

  loginDate: localStorage.getItem("loginDate")

};

      const response = await axios.post(
        "http://localhost:8080/api/cheque-dd/save",
        payload
      );

      alert("Saved Successfully");

      console.log(response.data);

      // OPTIONAL RESET
      setReceipt({
        chequeDdNo: "",
        chequeDdDate: "",
        referenceNo: "",
        purpose: "",
        fromWhom: "",
        amount: "",
        bankCreditDate: "",
      });

    } catch (error) {

      console.error(error);

      if (error.response && error.response.data) {

        alert(error.response.data);

      } else {

        alert("Save Failed");

      }
    }
  };

  return (

    <div className="cdr-page">

      <div className="cdr-header">

        <h1>PUBLIC FUND</h1>

        <h2>Cheque / DD RECEIPT</h2>

        <button
          className="cdr-menu-btn"
          onClick={() => navigate("/receipts")}
        >
          MENU
        </button>

      </div>

      <div className="cdr-form-container">

        <form onSubmit={handleSubmit}>

          <div className="cdr-row">

            <div className="cdr-field">

              <label>CHEQUE / DD NO :</label>

             <input
  type="text"
  name="chequeDdNo"
  maxLength="15"
  value={receipt.chequeDdNo}
  onChange={(e) => {

    const value = e.target.value;

    if (/^\d*$/.test(value)) {

      setReceipt({
        ...receipt,
        chequeDdNo: value,
      });

    } else {

      alert("Cheque / DD No should contain only digits");

    }

  }}
/>
            </div>

            <div className="cdr-field">

              <label>CHEQUE / DD DATE :</label>

              <input
                type="date"
                name="chequeDdDate"
                value={receipt.chequeDdDate}
                onChange={handleChange}
              />

            </div>

          </div>

          <div className="cdr-row">

            <div className="cdr-field">

              <label>REFERENCE NO / LETTER NO :</label>
<input
  type="text"
  name="referenceNo"
  maxLength="25"
  value={receipt.referenceNo}
  onChange={handleChange}
  onBlur={(e) => {
    if (!e.target.value.trim()) {
      alert("Reference No is required");
    }
  }}
/>

            </div>

            <div className="cdr-field">

              <label>PURPOSE :</label>

              <input
  type="text"
  name="purpose"
  maxLength="50"
  value={receipt.purpose}
  onChange={handleChange}
  onBlur={(e) => {
    if (!e.target.value.trim()) {
      alert("Purpose is required");
    }
  }}
/>
            </div>

          </div>

          <div className="cdr-row">

            <div className="cdr-field from-whom-field">

              <label>FROM WHOM :</label>

              <textarea
                name="fromWhom"
                maxLength="100"
                onBlur={(e) => {
  if (!e.target.value.trim()) {
    alert("From Whom is required");
  }
}}
                value={receipt.fromWhom}
                onChange={(e) => {

                  handleChange(e);

                  e.target.style.height = "auto";

                  e.target.style.height =
                    e.target.scrollHeight + "px";
                }}
              />

            </div>

            <div className="cdr-field">

              <label>AMOUNT :</label>

              <input
                type="text"
                name="amount"
                maxLength="10"
                value={receipt.amount}
                onChange={(e) => {

                  const value = e.target.value;

                 if (/^\d{0,9}(\.\d{0,2})?$/.test(value)) {
                  if (Number(value) > 999999999.99) {
  alert("Amount cannot exceed 999999999.99");
  return;
}

                    setReceipt({
                      ...receipt,
                      amount: value,
                    });

                  } else {

                  alert(
  "Amount should contain only numbers and up to 2 decimal places"
);

                  }
                }}
              />

            </div>

          </div>

          <div className="cdr-row">

            <div className="cdr-field single-field">

              <label>BANK CREDIT DATE:</label>

              <input
                type="date"
                name="bankCreditDate"
                value={receipt.bankCreditDate}
                onChange={handleChange}
                
              />

            </div>

          </div>

          <div className="cdr-save-btn-div">

            <button type="submit" className="cdr-save-btn">
              SAVE
            </button>

          </div>

        </form>

      </div>

    </div>
  );
};

export default ChequeDdReceipt;