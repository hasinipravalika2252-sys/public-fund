package com.pf.login.service;

import com.pf.login.dto.ChequeDdReceiptDto;
import com.pf.login.entity.RBillOne;
import com.pf.login.entity.ReceiptOne;
import com.pf.login.entity.Trcd;
import com.pf.login.repository.RBillOneRepository;
import com.pf.login.repository.ReceiptRepository;
import com.pf.login.repository.TrcdRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class BillService {

    @Autowired
    private RBillOneRepository billRepository;

    @Autowired
    private ReceiptRepository receiptRepository;
    @Autowired
private TrcdRepository trcdRepository;

    public Long saveBill(RBillOne billRequest) {

        // 1️⃣ Get latest receipt (MAX CONTNO)
        ReceiptOne receipt = receiptRepository.findLatestReceipt();

        if (receipt == null) {
            throw new RuntimeException("No receipt found in RECEIPTS_ONE table");
        }

        Long latestContno = receipt.getContno();
        BigDecimal receiptAmount = receipt.getAmount();

        // 2️⃣ Get total bill amount already used
        BigDecimal existingTotal = billRepository.getTotalBillAmount(latestContno);

        if (existingTotal == null) {
            existingTotal = BigDecimal.ZERO;
        }

        // 3️⃣ Duplicate check (Bill No + Bill Date)
        boolean exists = billRepository.existsByBillNoAndBillDate(
                billRequest.getBillNo(),
                billRequest.getBillDate()
        );

        if (exists) {
            throw new RuntimeException("Bill No + Bill Date combination should not repeat");
        }

        // 4️⃣ Validate amount
        BigDecimal newTotal = existingTotal.add(billRequest.getBillAmount());

        if (newTotal.compareTo(receiptAmount) > 0) {
            throw new RuntimeException("TOTAL AMOUNT EXCEEDS BILL AMOUNT");
        }

        // 5️⃣ Generate RVNO
        String rvPrefix = LocalDate.now()
                .format(DateTimeFormatter.ofPattern("yyyyMM"));

        Long rvStart = Long.parseLong(rvPrefix + "0000");
        Long rvEnd   = Long.parseLong(rvPrefix + "9999");

        Long maxRvno = billRepository.findMaxRvnoInRange(rvStart, rvEnd);

        Long newRvno;

        if (maxRvno == null) {
            newRvno = Long.parseLong(rvPrefix + "0001");
        } else {
            newRvno = maxRvno + 1;
        }

        // 6️⃣ Generate CONTNO
        String contPrefix = String.valueOf(LocalDate.now().getYear());

        Long contStart = Long.parseLong(contPrefix + "00000");
        Long contEnd   = Long.parseLong(contPrefix + "99999");

        Long maxContno = billRepository.findMaxContnoInRange(contStart, contEnd);

        Long newContno;

        if (maxContno == null) {
            newContno = Long.parseLong(contPrefix + "00001");
        } else {
            newContno = maxContno + 1;
        }

        // 7️⃣ Set values
        billRequest.setContno(newContno);

        billRequest.setRvno(newRvno);

        billRequest.setType("MIS");

        billRequest.setBalance(billRequest.getBillAmount());

        billRequest.setAlertFlag("N");

        if (billRequest.getBillDate() == null) {
            billRequest.setBillDate(LocalDate.now());
        }

        // 8️⃣ Save
        billRepository.save(billRequest);

        return newRvno;
    }

    // 🔹 Fetch latest bill using MAX(RVNO)
    public RBillOne getLatestBill() {
        return billRepository.findLatestBill();
    }
    public Long saveChequeDd(ChequeDdReceiptDto dto) {

    LocalDate loginDate = dto.getLoginDate();

    // =========================
    // CONTNO
    // =========================
    String year = String.valueOf(loginDate.getYear());

    Long maxContno =
            receiptRepository.findMaxContnoForYear(year);

    long nextContSeq =
            (maxContno == null)
                    ? 1
                    : (maxContno % 100000) + 1;

    Long contno =
            Long.parseLong(
                    year + String.format("%05d", nextContSeq)
            );

    // =========================
    // RVNO
    // =========================
    String yearMonth =
            year + String.format("%02d",
                    loginDate.getMonthValue());

    Long rvStart =
            Long.parseLong(yearMonth + "0000");

    Long rvEnd =
            Long.parseLong(yearMonth + "9999");

    Long maxRvno =
            receiptRepository.findMaxRvnoInRange(
                    rvStart,
                    rvEnd
            );

    Long rvno =
            (maxRvno == null)
                    ? Long.parseLong(yearMonth + "0001")
                    : maxRvno + 1;

    // =========================
    // REC NO
    // =========================
    String maxRecNo =
            receiptRepository.findMaxRecNoForMonth(
                    yearMonth
            );

    int nextRecSeq =
            (maxRecNo == null)
                    ? 1
                    : Integer.parseInt(
                            maxRecNo.substring(6)
                    ) + 1;

    String recNo =
            yearMonth
                    + String.format("%04d", nextRecSeq);

    // =========================
    // TRCD
    // =========================
    Trcd trcd =
            trcdRepository.findById("R5")
                    .orElseThrow(() ->
                            new RuntimeException(
                                    "TRCD R4 not found"
                            ));

    // =========================
    // RECEIPTS_ONE
    // =========================
    ReceiptOne receipt = new ReceiptOne();

    receipt.setContno(contno);
    receipt.setRvno(rvno);

    receipt.setRecNo(recNo);

    receipt.setDvnoRefno(dto.getReferenceNo());

    receipt.setChequeReceiptNo(
            Long.parseLong(dto.getChequeDdNo())
    );

    receipt.setChequeReceiptDate(
            dto.getChequeDdDate()
    );

    receipt.setAmount(dto.getAmount());

    receipt.setBalance(dto.getAmount());

    receipt.setRPurpose(dto.getPurpose());

    receipt.setRType("MISC");

    receipt.setFromAddress(
            dto.getFromWhom()
    );

    receipt.setTrcd("R5");

    receipt.setTrcdDesc(
            trcd.getTrcdDesc()
    );

    receipt.setChequeCash("CH");

    receipt.setTrDate(loginDate);

    receipt.setAlertFlag("N");

    receipt.setBankCreditDate(
            dto.getBankCreditDate()
    );

    receiptRepository.save(receipt);

    // =========================
    // R_BILL_ONE
    // =========================
    RBillOne bill = new RBillOne();

    bill.setContno(contno);

    bill.setRvno(rvno);

    bill.setType("MIS");

    bill.setPurpose(
            dto.getPurpose()
    );

    bill.setBillAmount(
            dto.getAmount()
    );

    bill.setBalance(
            dto.getAmount()
    );

    bill.setAlertFlag("N");

    billRepository.save(bill);

    return rvno;
}

    

}
