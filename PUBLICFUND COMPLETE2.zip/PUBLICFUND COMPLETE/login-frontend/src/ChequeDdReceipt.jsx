import React, { useState } from "react";
import "./ChequeDdReceipt.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const ChequeDdReceipt = () => {

  const navigate = useNavigate();

  const [receipt, setReceipt] = useState({
    chequeDdNo: "",
    chequeDdDate: "",
    referenceNo: "",
    purpose: "",
    fromWhom: "",
    amount: "",
    bankCreditDate: "",
  });
  
  const handleChange = (e) => {

  const { name, value } = e.target;

  if (name === "chequeDdNo") {

    if (!/^\d*$/.test(value)) {
      alert("Cheque/DD No must contain only digits");
      return;
    }

    if (value.length > 15) {
      alert("Cheque/DD No maximum 15 digits");
      return;
    }
  }

  if (name === "referenceNo") {

    if (value.length > 25) {
      alert("Reference No maximum 25 characters");
      return;
    }
  }

  if (name === "purpose") {

    if (value.length > 50) {
      alert("Purpose maximum 50 characters");
      return;
    }
  }

  if (name === "fromWhom") {

    if (value.length > 100) {
      alert("From Whom maximum 100 characters");
      return;
    }
  }

  if (name === "amount") {

    if (!/^\d*\.?\d{0,2}$/.test(value)) {
      alert("Amount allows only numbers and 2 decimal places");
      return;
    }

    if (value.replace(".", "").length > 11) {
      alert("Amount maximum 11 digits");
      return;
    }
  }

  setReceipt({
    ...receipt,
    [name]: value,
  });
};

  // ✅ SAVE FUNCTION
  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

      const payload = {

  chequeDdNo: receipt.chequeDdNo,
  chequeDdDate: receipt.chequeDdDate,
  referenceNo: receipt.referenceNo,
  purpose: receipt.purpose,
  fromWhom: receipt.fromWhom,
  amount: receipt.amount,
  bankCreditDate: receipt.bankCreditDate,

  loginDate: localStorage.getItem("loginDate")

};
      

      const response = await axios.post(
        "http://localhost:8080/api/bill/save",
        payload
      );

      alert("Saved Successfully");

      console.log(response.data);

      // OPTIONAL RESET
      setReceipt({
        chequeDdNo: "",
        chequeDdDate: "",
        referenceNo: "",
        purpose: "",
        fromWhom: "",
        amount: "",
        bankCreditDate: "",
      });

    } catch (error) {

      console.error(error);

      if (error.response && error.response.data) {

        alert(error.response.data);

      } else {

        alert("Save Failed");

      }
    }
  };

  return (

    <div className="cdr-page">

      <div className="cdr-header">

        <h1>PUBLIC FUND</h1>

        <h2>Cheque / DD RECEIPT</h2>

        <button
          className="cdr-menu-btn"
          onClick={() => navigate("/receipts")}
        >
          MENU
        </button>

      </div>

      <div className="cdr-form-container">

        <form onSubmit={handleSubmit}>

          <div className="cdr-row">

            <div className="cdr-field">

              <label>CHEQUE / DD NO :</label>

              <input
                type="text"
                name="chequeDdNo"
                  maxLength="15"
                value={receipt.chequeDdNo}
                onChange={handleChange}
              />

            </div>

            <div className="cdr-field">

              <label>CHEQUE / DD DATE :</label>

              <input
                type="date"
                name="chequeDdDate"
                value={receipt.chequeDdDate}
                onChange={handleChange}
              />

            </div>

          </div>

          <div className="cdr-row">

            <div className="cdr-field">

              <label>REFERENCE NO / LETTER NO :</label>

              <input
                type="text"
                name="referenceNo"
                  maxLength="15"
                value={receipt.referenceNo}
                onChange={handleChange}
              />

            </div>

            <div className="cdr-field">

              <label>PURPOSE :</label>

              <input
                type="text"
                name="purpose"
                  maxLength="50"
                value={receipt.purpose}
                onChange={handleChange}
              />

            </div>

          </div>

          <div className="cdr-row">

            <div className="cdr-field from-whom-field">

              <label>FROM WHOM :</label>

              <textarea
                name="fromWhom"
                value={receipt.fromWhom}
                onChange={(e) => {

                  handleChange(e);

                  e.target.style.height = "auto";

                  e.target.style.height =
                    e.target.scrollHeight + "px";
                }}
              />

            </div>

            <div className="cdr-field">

              <label>AMOUNT :</label>

              <input
  type="text"
  name="amount"
  value={receipt.amount}
  onChange={handleChange}
/>

            </div>

          </div>

          <div className="cdr-row">

            <div className="cdr-field single-field">

              <label>BANK CREDIT DATE:</label>

              <input
                type="date"
                name="bankCreditDate"
                value={receipt.bankCreditDate}
                onChange={handleChange}
              />

            </div>

          </div>

          <div className="cdr-save-btn-div">

            <button type="submit" className="cdr-save-btn">
              SAVE
            </button>

          </div>

        </form>

      </div>

    </div>
  );
};

export default ChequeDdReceipt;