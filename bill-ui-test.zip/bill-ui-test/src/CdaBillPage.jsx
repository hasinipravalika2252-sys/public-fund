import React, { useState } from "react";
import "./CdaBillPage.css";

const CdaBillPage = () => {
  const [typeValue, setTypeValue] = useState("Nill");

  return (
    <div className="container">
      <h2 className="title">PUBLIC FUND</h2>
      <h3 className="subtitle">BILL FROM CDA</h3>

      {/* Top Rows (6 columns aligned) */}
      <div className="top-rows">
        <div>
          <label>Receipt No</label>
          <input className="small-input" />
        </div>

        <div>
          <label>CDA DVNO</label>
          <input className="small-input" />
        </div>

        <div>
          <label>CDA Cheque No</label>
          <input className="small-input" />
        </div>

        <div>
          <label>CDA Cheque Date</label>
          <input type="date" className="small-input" />
        </div>

        <div>
          <label>Cheque Slip Amount</label>
          <input type="number" className="small-input" />
        </div>

        <div>
          <label>Bank Credit Date</label>
          <input type="date" className="small-input" />
        </div>
      </div>

      {/* Bill Table */}
      <table className="bill-table">
        <thead>
          <tr>
            <th>RV No</th>
            <th>Bill No</th>
            <th>Bill Date</th>
            <th>Bill Amount</th>
            <th>Type</th>
            <th>Purpose</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><input className="table-input" /></td>
            <td><input className="table-input" /></td>
            <td><input type="date" className="table-input" /></td>
            <td><input type="number" className="table-input" /></td>
            <td><input className="table-input" /></td>
            <td><input className="table-input" /></td>
          </tr>
        </tbody>
      </table>

      {/* Middle Rows */}
      <div className="middle-rows">
        <div>
          <label>ID No</label>
          <input className="small-input" />
        </div>

        <div>
          <label>PER No</label>
          <input className="small-input" />
        </div>

        <div>
          <label>Name</label>
          <input className="small-input" />
        </div>

        <div>
          <label>Amount</label>
          <input type="number" className="small-input" />
        </div>

        <div>
          <label>Cashbook Amount</label>
          <input type="number" className="small-input" />
        </div>

        <div>
          <label>Type</label>
          <select
            className="small-input"
            value={typeValue}
            onChange={(e) => setTypeValue(e.target.value)}
          >
            <option>Nill</option>
            <option>2</option>
            <option>10</option>
          </select>
        </div>
      </div>

      {/* Tax Section */}
      {typeValue !== "Nill" && (
        <div className="epic-tax-row">
          <label>CGST</label>
          <input className="epic-small" defaultValue="0.00" />
          <input className="epic-small" defaultValue="0.00" />

          <label>SGST</label>
          <input className="epic-small" defaultValue="0.00" />
          <input className="epic-small" defaultValue="0.00" />

          <label>Base Amount</label>
          <input className="epic-medium" />

          <label>Net Amount</label>
          <input className="epic-medium" />

          <label>TDS Amount</label>
          <input className="epic-medium" />
        </div>
      )}

      {/* Save Button */}
      <div className="save-container">
        <button className="save-btn">SAVE</button>
      </div>

      {/* Bottom Section */}
      <div className="bottom-section">
        <div className="box">
          <strong>DRDO Employee Details</strong>
        </div>

        <div className="box">
          <strong>Other Persons Details</strong>
        </div>
      </div>

      <div className="center-btn">
        <button className="small-btn">Another Bill</button>
      </div>

      <div className="left-btn">
        <button className="small-btn">Add another Receipt</button>
      </div>
    </div>
  );
};

export default CdaBillPage;