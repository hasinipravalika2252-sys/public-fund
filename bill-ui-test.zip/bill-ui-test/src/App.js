import React from "react";
import CdaBillPage from "./CdaBillPage";

function App() {
  return (
    <>
      <CdaBillPage />
    </>
  );
}

export default App;