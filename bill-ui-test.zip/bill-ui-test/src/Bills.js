import React from "react";
import "./Bills.css";

function Bills() {
  return (
    <div className="bill-page">
      <div className="bill-container">
        <h1 className="title">PUBLIC FUND</h1>
        <h3 className="subtitle">BILL FROM CDA</h3>

        <div className="form-grid">

          <div className="form-group">
            <label>REC NO</label>
            <input type="text" />
          </div>

          <div className="form-group">
            <label>CDA DVNO</label>
            <input type="text" />
          </div>

          <div className="form-group">
            <label>CDA CHEQUE NO</label>
            <input type="text" />
          </div>

          <div className="form-group">
            <label>CDA CHEQUE DATE</label>
            <input type="date" />
          </div>

          <div className="form-group">
            <label>CHEQUE SLIP TOTAL AMOUNT</label>
            <input type="text" />
          </div>

          <div className="form-group">
            <label>BANK CREDIT DATE</label>
            <input type="date" />
          </div>

          <div className="form-group">
            <label>TYPE</label>
            <select>
              <option>Select</option>
            </select>
          </div>

          <div className="form-group">
            <label>PURPOSE</label>
            <select>
              <option>Select</option>
            </select>
          </div>

          <div className="form-group">
            <label>BILL NO</label>
            <input type="text" />
          </div>

          <div className="form-group">
            <label>BILL DATE</label>
            <input type="date" />
          </div>

          <div className="form-group">
            <label>BILL AMOUNT</label>
            <input type="text" />
          </div>

        </div>

        <div className="button-container">
          <button className="save-btn">SAVE BILL</button>
        </div>

      </div>
    </div>
  );
}

export default Bills;
